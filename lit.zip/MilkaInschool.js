s = document.createElement('style');
s.innerText = '.navbar{background-color : DarkMagenta}';
document.getElementsByTagName('head')[0].appendChild(s);
document.getElementsByClassName("wilma-logo")[0].src ="https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/Milka_purple_logo18.svg/1920px-Milka_purple_logo18.svg.png";
document.getElementsByClassName("wilma-logo")[0].style = "filter: brightness(0) invert(1);";